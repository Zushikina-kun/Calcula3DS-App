#include <3ds.h>
#include <citro3d.h>
#include <citro2d.h>

#include "keyboard.h"
#include "graph_mode.h"
#include "sleep_hook.h"
#include "theme.h"

#include <cstdio>

u32 __stacksize__ = 512 * 1024;

static void termhandler()
{
    svcBreak(USERBREAK_PANIC);
}

int main(int argc, char** argv)
{
    std::set_terminate(termhandler);
    gfxInitDefault();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();

    u32 old_time_limit;
    APT_GetAppCpuTimeLimit(&old_time_limit);
    APT_SetAppCpuTimeLimit(30);

    hidSetRepeatParameters(15, 8);

    C3D_RenderTarget* top    = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    C3D_RenderTarget* bottom = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);

    consoleDebugInit(debugDevice_SVC);

    romfsInit();
    C2D_SpriteSheet sprites = C2D_SpriteSheetLoad("romfs:/gfx/sprites.t3x");
    romfsExit();

    // Start in dark mode — feels better on the 3DS screen in most lighting.
    Theme::set(Theme::DARK);

    Keyboard kb(sprites);
    GraphMode graph(sprites);
    AppLifecycleHook lifecycle;

    bool in_graph_mode = false;
    constexpr u32 CIRCLE_PAD_VALUES = (KEY_CPAD_UP | KEY_CPAD_DOWN | KEY_CPAD_LEFT | KEY_CPAD_RIGHT);

    // Theme toggle: hold START for ~1 second then press SELECT to switch.
    // Tracked with a simple timestamp so a brief START tap still quits.
    u64 start_held_since = 0;
    bool start_was_held  = false;
    constexpr u64 THEME_HOLD_MS = 800;

    while(aptMainLoop())
    {
        gspWaitForVBlank();

        // Sleep/resume hardening: force a full redraw on the graph screen
        // after returning from HOME menu or system sleep.
        if(lifecycle.consume_resume_flag())
        {
            graph.invalidate();
        }

        hidScanInput();
        u32 kDown  = hidKeysDown();
        u32 kHeld  = hidKeysHeld();
        u32 kDownRepeat = hidKeysDownRepeat();

        // Quit: START tapped alone (not held for theme toggle)
        if((kDown & KEY_START) && !(kHeld & KEY_SELECT))
        {
            // start the hold timer
            if(!start_was_held)
            {
                start_held_since = osGetTime();
                start_was_held   = true;
            }
        }
        if(!(kHeld & KEY_START))
        {
            if(start_was_held)
            {
                // released before threshold → treat as quit
                if(osGetTime() - start_held_since < THEME_HOLD_MS)
                    break;
                start_was_held = false;
            }
        }

        // Theme toggle: START held + SELECT pressed
        if((kHeld & KEY_START) && (kDown & KEY_SELECT))
        {
            start_was_held = false; // consume the hold, don't quit
            Theme::set(Theme::current() == Theme::DARK ? Theme::LIGHT : Theme::DARK);
            graph.invalidate(); // graph colours changed, resample display
        }
        // Mode toggle: SELECT alone (START not held)
        else if((kDown & KEY_SELECT) && !(kHeld & KEY_START))
        {
            in_graph_mode = !in_graph_mode;
        }

        const bool calculating = kb.calculating();

        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);

        C2D_TargetClear(top,    Theme::BG);
        C2D_TargetClear(bottom, Theme::BG);

        if(in_graph_mode)
        {
            graph.update();

            C2D_SceneBegin(top);
            graph.draw_top(sprites);

            C2D_SceneBegin(bottom);
            graph.draw_bottom(sprites);
        }
        else
        {
            if(!calculating)
            {
                kb.do_clears();
                kb.update_memory(sprites);
                kb.update_equation(sprites);
            }

            C2D_SceneBegin(top);
            kb.draw_memory(sprites);
            if(calculating)
                C2D_DrawRectSolid(0, 0, 1.0f, 400, 240, Theme::CALC_OVERLAY);

            C2D_SceneBegin(bottom);
            kb.draw(sprites);
            if(calculating)
            {
                C2D_DrawRectSolid(0, 0, 0.875f, 320, 240, Theme::CALC_OVERLAY);
                kb.draw_loader();
            }
        }

        C3D_FrameEnd(0);

        if(in_graph_mode)
        {
            if((kDownRepeat | kDown) & ~(KEY_TOUCH | CIRCLE_PAD_VALUES | KEY_SELECT | KEY_START))
                graph.handle_buttons(kDown, kDownRepeat);
            else if(kDown & KEY_TOUCH)
            {
                touchPosition pos;
                hidTouchRead(&pos);
                graph.handle_touch(pos.px, pos.py);
            }
            else if(kHeld & CIRCLE_PAD_VALUES)
            {
                circlePosition pos;
                hidCircleRead(&pos);
                if(abs(pos.dx) > 20 || abs(pos.dy) > 20)
                    graph.handle_circle_pad(pos.dx, pos.dy);
            }
        }
        else
        {
            if(!calculating)
            {
                if((kDownRepeat | kDown) & ~(KEY_TOUCH | CIRCLE_PAD_VALUES | KEY_SELECT | KEY_START))
                    kb.handle_buttons(kDown, kDownRepeat);
                else if(kDown & KEY_TOUCH)
                {
                    touchPosition pos;
                    hidTouchRead(&pos);
                    kb.handle_touch(pos.px, pos.py);
                }
                else if(kHeld & CIRCLE_PAD_VALUES)
                {
                    circlePosition pos;
                    hidCircleRead(&pos);
                    if(abs(pos.dx) > 20 || abs(pos.dy) > 20)
                        kb.handle_circle_pad(pos.dx, pos.dy);
                }
            }
        }
    }

    C2D_SpriteSheetFree(sprites);

    if(old_time_limit != UINT32_MAX) APT_SetAppCpuTimeLimit(old_time_limit);

    C2D_Fini();
    C3D_Fini();
    gfxExit();
}
