#include "theme.h"

namespace Theme {

// ---------------------------------------------------------------------------
// Storage for all theme variables. Initialised to LIGHT values.
// ---------------------------------------------------------------------------
u32 BG            = C2D_Color32(255, 255, 255, 255);
u32 SURFACE       = C2D_Color32(230, 230, 230, 255);
u32 SURFACE2      = C2D_Color32(200, 200, 200, 255);

u32 FG            = C2D_Color32(  0,   0,   0, 255);
u32 FG_DIM        = C2D_Color32(120, 120, 120, 255);
u32 FG_ARROW      = C2D_Color32(  0,   0,   0, 140);

u32 KEY_FACE      = C2D_Color32( 90,  95, 145, 255);
u32 KEY_LABEL     = C2D_Color32(255, 255, 255, 255);

u32 DIM_OVERLAY   = C2D_Color32( 32,  32,  32,  72);
u32 CALC_OVERLAY  = C2D_Color32( 80,  80,  80, 110);

u32 GRAPH_BG      = C2D_Color32(255, 255, 255, 255);
u32 GRAPH_GRID    = C2D_Color32(210, 210, 210, 255);
u32 GRAPH_AXIS    = C2D_Color32(  0,   0,   0, 255);
u32 GRAPH_CURVE   = C2D_Color32( 30,  90, 220, 255);
u32 GRAPH_BOX_OK  = C2D_Color32(200, 200, 200, 255);
u32 GRAPH_BOX_ERR = C2D_Color32(220, 120, 120, 255);
u32 GRAPH_ERR_TXT = C2D_Color32(180,   0,   0, 255);

u32 ANS_BAR_BG    = C2D_Color32(200, 200, 200, 255);
u32 ANS_BAR_FG    = C2D_Color32(  0,   0,   0, 255);

u32 CURSOR        = C2D_Color32(  0,   0,   0, 255);
u32 SEPARATOR     = C2D_Color32(  0,   0,   0, 255);

// ---------------------------------------------------------------------------

static ID current_theme = LIGHT;
ID current() { return current_theme; }

void set(ID id)
{
    current_theme = id;

    if(id == DARK)
    {
        // Material-inspired dark surface palette
        BG            = C2D_Color32( 18,  18,  18, 255); // #121212
        SURFACE       = C2D_Color32( 13,  13,  13, 255); // #0D0D0D  gap bar
        SURFACE2      = C2D_Color32( 30,  30,  30, 255); // #1E1E1E  answer / memory

        FG            = C2D_Color32(220, 220, 220, 255); // #DCDCDC
        FG_DIM        = C2D_Color32(110, 110, 120, 255); // muted secondary
        FG_ARROW      = C2D_Color32(220, 220, 220, 140); // semi-transparent light

        KEY_FACE      = C2D_Color32( 42,  42,  58, 255); // #2A2A3A dark slate
        KEY_LABEL     = C2D_Color32(210, 220, 255, 255); // soft blue-white

        DIM_OVERLAY   = C2D_Color32(  0,   0,   0,  90);
        CALC_OVERLAY  = C2D_Color32(  0,   0,   0, 130);

        GRAPH_BG      = C2D_Color32( 10,  10,  20, 255); // #0A0A14 deep navy
        GRAPH_GRID    = C2D_Color32( 26,  26,  42, 255); // #1A1A2A subtle
        GRAPH_AXIS    = C2D_Color32( 80,  80, 110, 255); // #50506E muted axis
        GRAPH_CURVE   = C2D_Color32( 91, 155, 255, 255); // #5B9BFF bright blue
        GRAPH_BOX_OK  = C2D_Color32( 35,  35,  50, 255); // dark input box
        GRAPH_BOX_ERR = C2D_Color32( 74,  16,  16, 255); // #4A1010 dark red
        GRAPH_ERR_TXT = C2D_Color32(255,  96,  96, 255); // #FF6060

        ANS_BAR_BG    = C2D_Color32( 25,  25,  35, 255);
        ANS_BAR_FG    = C2D_Color32(220, 220, 220, 255);

        CURSOR        = C2D_Color32(160, 200, 255, 255); // accent blue cursor
        SEPARATOR     = C2D_Color32( 42,  42,  55, 255);
    }
    else // LIGHT
    {
        BG            = C2D_Color32(255, 255, 255, 255);
        SURFACE       = C2D_Color32(230, 230, 230, 255);
        SURFACE2      = C2D_Color32(200, 200, 200, 255);

        FG            = C2D_Color32(  0,   0,   0, 255);
        FG_DIM        = C2D_Color32(120, 120, 120, 255);
        FG_ARROW      = C2D_Color32(  0,   0,   0, 140);

        KEY_FACE      = C2D_Color32( 90,  95, 145, 255);
        KEY_LABEL     = C2D_Color32(255, 255, 255, 255);

        DIM_OVERLAY   = C2D_Color32( 32,  32,  32,  72);
        CALC_OVERLAY  = C2D_Color32( 80,  80,  80, 110);

        GRAPH_BG      = C2D_Color32(255, 255, 255, 255);
        GRAPH_GRID    = C2D_Color32(210, 210, 210, 255);
        GRAPH_AXIS    = C2D_Color32(  0,   0,   0, 255);
        GRAPH_CURVE   = C2D_Color32( 30,  90, 220, 255);
        GRAPH_BOX_OK  = C2D_Color32(200, 200, 200, 255);
        GRAPH_BOX_ERR = C2D_Color32(220, 120, 120, 255);
        GRAPH_ERR_TXT = C2D_Color32(180,   0,   0, 255);

        ANS_BAR_BG    = C2D_Color32(200, 200, 200, 255);
        ANS_BAR_FG    = C2D_Color32(  0,   0,   0, 255);

        CURSOR        = C2D_Color32(  0,   0,   0, 255);
        SEPARATOR     = C2D_Color32(  0,   0,   0, 255);
    }
}

} // namespace Theme
