#ifndef INC_CALCMODE_H
#define INC_CALCMODE_H

// ---------------------------------------------------------------------------
// Angle mode for trigonometric functions.
//
// When DEG is active, all trig inputs are treated as degrees and inverse
// trig outputs are in degrees. When RAD (default), no conversion happens.
//
// Usage:
//   CalcMode::set_angle(CalcMode::DEG);
//   bool is_deg = CalcMode::is_degrees();
// ---------------------------------------------------------------------------

namespace CalcMode {

enum AngleMode { RAD = 0, DEG = 1 };

void        set_angle(AngleMode m);
AngleMode   angle_mode();
bool        is_degrees();

// Convert input to radians for trig functions
double      to_rad(double v);
// Convert radians output back to display units for inverse trig
double      from_rad(double v);

} // namespace CalcMode

#endif
