#include "calcmode.h"
#include <cmath>

namespace CalcMode {

static AngleMode current_mode = RAD;

void set_angle(AngleMode m) { current_mode = m; }
AngleMode angle_mode()      { return current_mode; }
bool is_degrees()           { return current_mode == DEG; }

double to_rad(double v)
{
    return is_degrees() ? v * (M_PI / 180.0) : v;
}

double from_rad(double v)
{
    return is_degrees() ? v * (180.0 / M_PI) : v;
}

} // namespace CalcMode
