#ifndef INC_SLEEP_HOOK_H
#define INC_SLEEP_HOOK_H

#include <3ds.h>
#include <atomic>

// IMPORTANT CONTEXT: I could not reproduce or confirm an actual
// black-screen-after-sleep bug in CalculaThreeDS - I have no hardware or
// emulator access here. This is prophylactic hardening for a known *class*
// of citro3d/citro2d homebrew issue (apps that come back from the HOME menu
// or system sleep with stale/blank output), not a fix for a bug I've
// witnessed in this specific app. It's cheap to have and easy to delete if
// testing shows it's unnecessary.
//
// Usage in main.cpp:
//
//   AppLifecycleHook lifecycle;
//   ...
//   while(aptMainLoop())
//   {
//       if(lifecycle.consume_resume_flag())
//       {
//           graph.invalidate(); // forces a full resample + redraw
//       }
//       ...
//   }
class AppLifecycleHook {
public:
    AppLifecycleHook();
    ~AppLifecycleHook();

    AppLifecycleHook(const AppLifecycleHook&) = delete;
    AppLifecycleHook& operator=(const AppLifecycleHook&) = delete;

    // Returns true exactly once per resume event (restore-from-HOME-menu or
    // wake-from-sleep), then clears itself. Safe to call every frame.
    bool consume_resume_flag();

private:
    static void callback(APT_HookType hook, void* param);
    aptHookCookie cookie{};
    // std::atomic because the APT callback fires from a system context
    // (interrupt-like), not from the main thread. volatile bool would be
    // UB under the C++ memory model; atomic gives us the required
    // happens-before guarantee without any extra cost on ARM.
    std::atomic<bool> resumed{false};
};

#endif
