#ifndef INC_THEME_H
#define INC_THEME_H

#include <citro2d.h>

// ---------------------------------------------------------------------------
// Dual-theme palette for CalculaThreeDS.
//
// All colours previously in colors.h plus every inline hardcoded colour
// from keyboard.cpp, graph_mode.cpp, number.cpp are centralised here.
//
// Usage:
//   Theme::set(Theme::DARK);   // switch theme at runtime
//   C2D_DrawRectSolid(... Theme::BG);
//
// The toggle is START + held for 1 second — see main.cpp.
// The calculation thread never reads colours, so no synchronisation needed.
// ---------------------------------------------------------------------------

namespace Theme {

enum ID { LIGHT = 0, DARK = 1 };

void set(ID id);   // update all colour variables below
ID   current();    // returns LIGHT or DARK

// Backgrounds
extern u32 BG;           // main screen background (both screens)
extern u32 SURFACE;      // keyboard gap bar, dark inset areas
extern u32 SURFACE2;     // answer bar background, memory surface

// Foreground / text
extern u32 FG;           // primary text / strong lines
extern u32 FG_DIM;       // secondary text, hints, axis labels
extern u32 FG_ARROW;     // scroll arrow tint (semi-transparent)

// Interactive elements
extern u32 KEY_FACE;     // keyboard button fill
extern u32 KEY_LABEL;    // keyboard button label/icon tint

// Overlays
extern u32 DIM_OVERLAY;  // inactive screen / dim when top screen selected
extern u32 CALC_OVERLAY; // calculating spinner overlay

// Graph mode
extern u32 GRAPH_BG;     // graph plot background
extern u32 GRAPH_GRID;   // grid lines
extern u32 GRAPH_AXIS;   // X/Y axis lines
extern u32 GRAPH_CURVE;  // plotted function curve
extern u32 GRAPH_BOX_OK; // f(x) input box, expression valid
extern u32 GRAPH_BOX_ERR;// f(x) input box, expression invalid
extern u32 GRAPH_ERR_TXT;// parse error message text

// Answer bar (top screen strip)
extern u32 ANS_BAR_BG;   // 40px answer bar background
extern u32 ANS_BAR_FG;   // answer bar text tint

// Cursor & separators
extern u32 CURSOR;       // blinking text cursor rect
extern u32 SEPARATOR;    // 1px separator lines in memory view

// Never changes regardless of theme
static constexpr u32 TRANSPARENT = C2D_Color32(0, 0, 0, 0);

} // namespace Theme

#endif // INC_THEME_H
